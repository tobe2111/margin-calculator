import json, sys, glob
P = '/tmp/claude-0/-home-user-margin-calculator/5ddbbe10-216e-5605-a485-6492037f9404/scratchpad/'
idx = P + 'dino-viewer-live/index.html'
WANT = ["trex", "raptor", "allo", "trice", "stego", "spino", "spinosn", "brachiot", "brachiotrear", "diplo", "mammoth"]
s = open(idx).read(); lines = s.split('\n')
mi = [i for i, l in enumerate(lines) if l.startswith('const META=')][0]
oi = [i for i, l in enumerate(lines) if l.startswith('const ORDER=')][0]
META = json.loads(lines[mi][len('const META='):].rstrip(';'))
for f in sys.argv[1:]:
    META.update(json.load(open(f)))
order = [k for k in WANT if k in META] + [k for k in META if k not in WANT]
lines[mi] = 'const META=' + json.dumps(META, ensure_ascii=False) + ';'
lines[oi] = 'const ORDER=' + json.dumps(order) + ';'
open(idx, 'w').write('\n'.join(lines))
print(order)
