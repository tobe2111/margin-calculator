# House standard for all figures (user decisions)
- ALL RESIN, NO GLUE. Every joint holds by friction-fit square resin pins/pegs only.
  Targets per pin/joint: sustained bending stress < 5 MPa, 1 N push at the far tip < 20 MPa (resin ~60 MPa).
  Fixes when a joint fails: larger pin, second pin, longer engagement, keyed/interlocking socket shape.
  NEVER merge parts to avoid a joint: the product is an ASSEMBLY KIT the customer puts together. Keep (at least) the existing
  part split; joints stay, they just must hold with pins only (no glue). Keep bones visually unchanged.
- Base = FLAT PLATE: rounded rectangle, thickness 10 mm, corner radius 14 mm, flat top at z=0 (feet/supports stand on it),
  top edge chamfer 1.2 mm, no texture. Size: bounding rectangle of all foot/support positions + 34 mm front/back,
  +26 mm left/right (more if CoM margin needs it). Hollow from below: side walls 3 mm, top skin 3.5 mm; solid Ø15 mm
  cylinders under every foot/support so socket walls are strong.
  Build cleanly: shapely rounded rectangle -> trimesh.creation.extrude_polygon slab + convex-hull chamfer, union;
  cavity extrusion minus the Ø15 cylinders; subtract with manifold3d. Must be manifold NoError. If larger than the
  printer bed (218 x 123 mm, height 250), split into 2 with square-pin joints.
- Feet and supports fix into the plate with square 3.6 mm resin pins, plate socket depth >= 6 mm, soles exactly on z=0.
- Socket clearance: 0.1 mm per side (will be tuned after a test print).
- Every pin must be embedded in both parts; assembly must be possible in a stated order along pin axes (simulate).
- Report in Korean, plain language, with before/after numbers; render side, 3/4, top and LOOK at them.
- KIT GRANULARITY (user): every figure should be a kit like the MakerBot T-rex kit (≈20–35 parts): skull, jaw, neck,
  front/back dorsal sections, left/right ribs (or rib cages), scapulas, arms L/R, hip top/bottom (pelvis), femur L/R,
  tibia L/R, foot L/R, 3–4 tail sections, centre post(s), base plate, pins. Split along natural joints where the bone is
  thick enough for pins; every joint pin-only (no glue) and STURDY (targets above). Merging is never the answer.

## ACCEPTANCE CRITERIA (from the assembly-manual reviewer; these are what will be checked)
1. Part count 20–35 (incl. base & posts, excl. pins). Never merge to remove a joint. T-rex may keep its ~46.
2. Zero glue. EVERY touching part pair has ≥1 hidden square pin: sizes 4.2 / 3.6 / 3.0 / 2.6 mm; socket = pin + 0.1 mm
   per side; 0.12 mm crush ribs (press bumps) on the pin or socket. No butt joints without a pin. Foot→base: pin or a
   ≥3.5 mm peg.
3. Pin embed depth ≥ 1.5× pin size on EACH side; socket wall ≥ 1.2 mm; socket must not break through the surface.
4. Strength: every joint AND the thinnest section next to it has safety factor ≥ 5, with load = max(3 × static moment,
   weight × distance × 1.5) and resin 60 MPa (i.e. stress ≤ 12 MPa under that load). Joints carrying ≥100 g: 2 pins
   spaced ≥ 8 mm apart in the bending direction AND bone section ≥ 60 mm² at the joint.
5. Assemblable: all pins that a part engages simultaneously are parallel within 10°; insertion path collision-free.
   "Assemble body first, then lower onto the base" is an allowed order.
6. Tip-over threshold ≥ 0.6 g lateral (whole figure on its base). No isolated spikes thinner than 1 mm. Tail-tip core ≥ 2.5 mm.
Deliver a parts table: number, name, each joint's pin size/count/insertion direction.

## 2026-11-17 FINAL USER DECISION (confirmed directly) — semi-assembly CANCELLED
- Part split: keep current kits (customer assembles everything). No glue, no merged printing.
- Joint pins: resin square pins -> STAINLESS PARALLEL DOWEL PINS, tight press tolerance (no glue, no loosening),
  hole wall >= 1.2 mm so resin does not crack. Where bone too thin for the smallest dowel, keep resin pin (list it).
- Long thin parts (tail, neck): Ø2 stainless rod cores, hole Ø2.1, only where wall >= 1.2 mm.
- Support: Ø4 stainless rod (stock 50/100/200/250/300) + printed cylindrical plinth Ø20–30, Ø4.15 holes; >=1 foot pinned.
- Material: tough/ABS-like resin for strength checks.
- Stock parts: common Coupang sizes only; all 7 species <= 3–4 pin/core types (support rod excluded). Same as modeling session.
- Mis-assembly proof: each joint unique pin position/spacing/count or key shape; L/R parts cannot swap.
- Part numbers engraved small on hidden faces (TR-07, VR-03, MM-05; codes agreed with modeling session).
- Spare pins: +10% per size (min 1). Step bags matching manual steps in the kit list.

## 2026-11-18 USER DECISION
- Support rod (Ø4 stainless): NO spare in the kit (spare rule +10%/min 1 applies to dowels only).

## 2026-11-18 USER DECISION — crush ribs + hanging-joint list (confirmed directly)
- CRUSH RIBS in every metal dowel hole (A Ø3, B Ø2) and Ø4 rod hole: 3 vertical ribs at 120°, rib width 0.4–0.6 mm, entry chamfer 0.3 mm.
  - Tight (press) side: rib inner diameter = pin Ø − 0.05…0.1 mm; hole between ribs = pin Ø + 0.1…0.15 mm.
  - Slip (removable) side: rib inner diameter = pin Ø + 0…0.03 mm.
  - Keep wall ≥1.2 mm around the hole (measured to the enlarged hole); list holes that can't.
  - Not for resin square pins/keys. Print guide must say the values are to be tuned after a test print.
- HANGING-JOINT LIST per kit: joints where gravity pulls the pin out on display (head, jaw, tail, neck, arms...).
  - Columns: joint / part numbers / pin count / approx friction margin vs pull-out force / recommendation (as is | ribs enough | "원하면 순간접착제 한 방울").
  - Optional CA glue tip is allowed in this list only; the kit itself stays no-glue.
- Order: mammoth (now), raptor (from the start), T-rex after mammoth.

## 2026-11-18 (manual session request, user-approved) — support rod goes 18 mm into the plinth (was 8). Raise plinth top; same stock rod. Bone side ≥8.

## 2026-11-18 USER DECISION — hanging joints ≥3× without glue (confirmed directly)
- Every hanging joint must hold with pull-out margin ≥ 3× WITHOUT glue.
- Methods in order: (1) hidden shelf/ledge or catch so weight presses a face instead of pulling the pin;
  (2) press-side rib values on BOTH ends for joints never disassembled → manual marks "한 번 끼우면 고정";
  (3) add a pin or upsize B→A (only where 1.2 mm wall holds); (4) only if still <3×: keep "순간접착제 권장".
- Thin pin-hole walls <1.2 mm: add a small hidden boss on the unseen side to reach ≥1.2 mm. Review TX-53/54 jaw key walls the same way.
- Re-check after: full hanging table, assembly path, wrong-pairing block, tip-over.
- Order: T-rex right after mammoth v4.1; raptor uses the same rule.

## 2026-11-18 USER DECISION — mammoth (confirmed directly)
- Apply hollowing (skip MM-10 front body); 3 mm solid around holes/bosses; Ø3 ×2 hidden drains per cavity.
- Base minimized to 321×190 mm, FDM infill 15 %, single piece.

## 2026-11-18 USER DECISION — splits/tail/rod look (common standard v1.2, confirmed directly)
- Split at real bone boundaries (between vertebrae, at joints), not flat planar cuts.
- Long tail ≈ 3 pieces.
- Rod must not look thicker than the bone: bone ≥7 mm thick where a rod enters, else hidden boss.
- VR v8: apply now. TX/MM: list affected joints first (planar cuts, tail piece count, rod-bone thickness); owner decides fixes.
- Also common standard v1: rod stock 50/100/200/300 (no 250); part-number engraving 0.6 line / 0.8 depth; zip folders 뼈_SLA레진/, 받침판_FDM_PLA/, 출력_안내.md.

## 2026-11-18 USER DECISION — tip-over ≥0.7 g (common standard v1.3, confirmed directly)
- Tip-over limit raised 0.6 g → 0.7 g (all directions, real FDM plate weight). Plate = smallest size meeting 0.7 g.
- MM: enlarge plate to reach 0.7 g, must fit large box inside 340×290×100. TX: report the 0.7 g minimum plate (no change unless owner decides). VR v8: 0.7 g.

## 2026-11-18 (hub, standard v1.4 §9) — single box
- One box: Korea Post 2-1 black one-touch (outer ~350×250×100, inner ≥340×240×95). Old medium/large boxes dropped.
- Design limits: plate and largest part within 330×230 mm; plate + plinth height ≤85 mm; whole pack ≤95 mm.

## 2026-11-18 USER DECISION — mammoth body split (confirmed directly)
- MM v4.3 plate 321×203, 20 % infill (0.704 g). MM-09/MM-10 exceed 95 mm box height → split further at bone boundaries (v4.4), new numbers MM-20+.

## 2026-11-18 USER DECISION — hide supports (standard v1.5 §3, confirmed directly)
- Rods just in front of / behind the thighs (under dorsal spine / tail base), hidden behind legs from side; never mid-body or mid-tail. Prefer Ø4×100. Plinth slim (min Ø10, ~3 mm wall around rod). Anti-rotation: 2 rods or 1 rod + foot pin. Smallest plate for ≥0.7 g.
- Always compute: tip-over ≥0.7 g, rod-tip 1 N deflection ≤1 mm, bending stress ≤3 MPa at thinnest cantilevered tail/neck/head section.
- Weak joints: merge parts (within 330×230) before adding rods. Hanging ≥3× unchanged.
- VR v8: apply. TX/MM: before→after comparison table only; owner decides.

## 2026-11-18 USER (direct) — top principle
- "안정성과 디자인 그 두가지 요소를 모두 최대한 이상적으로 충족해야해": stability AND design both ideal. No silent trade-off: hidden fixes first; if a real conflict remains, show options with numbers/renders to the owner.

## 2026-11-18 USER DECISION — proceed with everything (standard v1.7, confirmed directly)
- Apply directly to TX, MM, VR (no list/table gate): bone-boundary splits, tail ≈3 pieces, hidden supports (v1.5), 0.7 g smallest plate, 2-1 box limits, engraving 0.6 width / 0.6–0.8 depth, §7 zip/file names.
- Ask the owner only for big visual changes or real stability-vs-design conflicts.
- After each kit: full re-check → new zip to owner → Blender Cycles 7 shots (TX, VR, MM) → artifact URL to hub; §10 table to hub; part numbers/bags to manual session.

## 2026-11-18 USER DECISION — mammoth v4.4/4.5 (confirmed directly)
- Body split at rib heads (costovertebral/costosternal). Rear rib-side slip holes may be <1.2 mm wall (accepted exception); front-right gets a small hidden joint block inside the chest.
- Support: short hidden rod under the chest between the forelegs (approved exception to "never mid-body") + rear rod by the thighs; visible neck rod removed.

## 2026-11-18 (hub, standard v1.9, owner-confirmed) — never cut a single bone
- Splits only where separate bones meet (rib↔vertebra, femur↔pelvis, between vertebrae, joints). A bone longer than the box → ask owner first. List remaining mid-bone joints for TX/MM/VR to hub.

## 2026-11-18 USER DECISION — raptor v8.1 (confirmed directly)
- Tail 2 pieces (merge tail A+B; one cut through ossified tendons accepted).
- Body + shoulder girdle merged into one part (removes 4 joints and lumps).
- L/R proofing for raptor: numbers + separate L/R bags only (no visible keys, no color difference).

## 2026-11-18 USER DECISION — T-rex rev6.4 + fossil texture (confirmed directly)
- Jaw merged into skull (no glue). Keep rev6.3 underside bosses. Thin parts: engrave 0.6 deep, else bag label.
- Re-cut 4 flat mid-bone joints at bone boundaries; pelvis top/bottom merged.
- Fossil texture + rebuilt teeth for TX, MM, VR (standard v2.2 §5, fossil_texture.py); large parts tiled or 0.12–0.15 grid due to RAM.
