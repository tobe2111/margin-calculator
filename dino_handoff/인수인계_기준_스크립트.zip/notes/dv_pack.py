#!/usr/bin/env python3
"""Pack a dinosaur kit into the '공룡 화석 보강판' viewer format.
Usage: python3 dv_pack.py KEY "한글 이름" "Sci name" out_dir part1.stl:GROUP part2.stl:GROUP ...
GROUP: 0 머리·목, 1 몸통, 2 다리, 3 꼬리, 4 지지대(봉·좌대 기둥), 5 받침판, 6 끼움 핀
Frame of the STL files: mm, Z up, plate top z=0, the long body axis along X or Y (any sign).
Writes out_dir/KEY.txt (keep ≤ 12 MB; raise GRID if bigger) and out_dir/KEY.meta.json."""
import sys, os, json, base64, numpy as np, trimesh
GRID = float(os.environ.get('GRID', '1.2'))  # mm vertex-merge grid for bones (plate uses 1.6)
key, ko, sci, out = sys.argv[1:5]; items = [a.rsplit(':', 1) for a in sys.argv[5:]]
Vs, Fs, Ls, off, M, CM = [], [], [], 0, 0.0, np.zeros(3)
for f, g in items:
    gi = int(g); t = trimesh.load(f, process=True)
    if gi != 5: M += abs(t.volume); CM += abs(t.volume) * t.center_mass
    gr = 1.6 if gi == 5 else GRID; v, fc = t.vertices, t.faces
    q = np.floor(v / gr).astype(np.int64); u, inv = np.unique(q, axis=0, return_inverse=True); inv = inv.ravel()
    nv = np.zeros((len(u), 3)); np.add.at(nv, inv, v); nv /= np.bincount(inv)[:, None]
    fc = inv[fc]; ok = (fc[:, 0] != fc[:, 1]) & (fc[:, 1] != fc[:, 2]) & (fc[:, 0] != fc[:, 2]); fc = fc[ok]
    Vs.append(nv); Fs.append(fc + off); Ls.append(np.full(len(nv), gi)); off += len(nv)
CM /= M; V = np.concatenate(Vs); F = np.concatenate(Fs); L = np.concatenate(Ls)
ext = V.max(0) - V.min(0); longax = 0 if ext[0] >= ext[1] else 1; side = 1 - longax
conv = lambda P: np.stack([np.atleast_2d(P)[:, side], np.atleast_2d(P)[:, 2], np.atleast_2d(P)[:, longax]], 1) / 10
Vv = conv(V); c = np.array([(Vv[:, 0].min() + Vv[:, 0].max()) / 2, Vv[:, 1].min(), (Vv[:, 2].min() + Vv[:, 2].max()) / 2]); Vv -= c
mn, mx = Vv.min(0), Vv.max(0); sc = (mx - mn) / 65535; Q = np.round((Vv - mn) / sc).astype('<u2')
os.makedirs(out, exist_ok=True)
open(f'{out}/{key}.txt', 'w').write(base64.b64encode(Q.tobytes() + L.astype('<u1').tobytes() + F.astype('<u4').tobytes()).decode())
com = conv(CM)[0] - c; fig = Vv[L < 5]; fe = (fig.max(0) - fig.min(0)) * 10
meta = {key: dict(ko=ko, sci=sci, n=int(len(Vv)), m=int(len(F)), min=[round(float(x), 4) for x in mn],
        scale=[float(x) for x in sc], com=[round(float(x), 3) for x in com],
        size_mm=[round(float(fe[2])), round(float(fe[0])), round(float(Vv[:, 1].max() * 10))],
        ext=[round(float(x), 2) for x in (mx - mn)], parts=len(items),
        cards=[["ok", "해결", "제목", "한 줄 설명(한글, 쉬운 말)"]])}
json.dump(meta, open(f'{out}/{key}.meta.json', 'w'), ensure_ascii=False, indent=1)
print(meta[key]['n'], meta[key]['m'], round(os.path.getsize(f'{out}/{key}.txt') / 1e6, 1), 'MB')
